<template>
    <div class="home">
        <Content />
    </div>    
</template>
<script>
import Content from '../components/ContentComponent.vue';
export default {
    name:'home',
      components:{
        Content
    }
}
</script>