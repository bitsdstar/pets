<template>
    <div class="login">
        <myRegister />
    </div>    
</template>
<script>
import myRegister from '../components/RegisterComponent.vue';
export default {
    name:'Register',
      components:{
        myRegister
    }
}
</script>