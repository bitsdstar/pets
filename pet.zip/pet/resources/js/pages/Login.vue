<template>
    <div class="login">
        <myLogin />
    </div>    
</template>
<script>
import myLogin from '../components/LoginComponent.vue';
export default {
    name:'Login',
      components:{
        myLogin
    }
}
</script>