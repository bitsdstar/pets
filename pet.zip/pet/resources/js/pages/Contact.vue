<template>
    <div>
        <p>Contact Us</p>
    </div>
    
</template>

<script>
// import Header from '../components/HeaderComponent.vue';
// import Content from '../components/ContentComponent.vue';
// import Footer from '../components/FooterComponent.vue';
export default {
    name:'Contact',
     components:{
       // Header,
        // Content,
        //Footer
    }
}
</script>