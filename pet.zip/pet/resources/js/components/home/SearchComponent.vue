<template>
	<div class="container">
		<div class="search_box">
			<div class="row">
				<div class="col-sm-3">
					<div class="form-group">
                        <input type="text" class="email_boton" placeholder="Search for" name="Email">
                    </div>
				</div>
				<div class="col-sm-3">
					<div class="form-group">
                        <input type="text" class="email_boton" placeholder="Loction in" name="Email">
                    </div>
				</div>
				<div class="col-sm-3">
					<div class="form-group">
                        <input type="text" class="email_boton" placeholder="category" name="Email">
                    </div>
				</div>
				<div class="col-sm-3">
					<div class="form-group">
                        <button class="search_bt">Search</button>
                    </div>
				</div>
				<div class="fashion_menu">
                    	<ul>
                    		<li class="active"><a href="#">Auto Mobile</a></li>
                    		<li><a href="#">Fashion</a></li>
                    		<li><a href="#">Mother& Child</a></li>
                    		<li><a href="#">Jobs</a></li>
                    		<li><a href="#">Real estate</a></li>
                    		<li><a href="#">Pets</a></li>
                    		<li><a href="#">Sport</a></li>
                    		<li><a href="#">More</a></li>
                    	</ul>
                    </div>
			</div>
		</div>
	</div>
</template>

<script>

export default {
    name:'Search'
}
</script>




