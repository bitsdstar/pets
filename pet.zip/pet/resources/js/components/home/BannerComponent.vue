<template>
	<div class="layout_padding banner_section">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h1 class="banner_taital">All You Need Is Here & Classified</h1>
					<p class="browse_text">Browse from more than 15,000,000 adverts while new ones come on daily bassis</p>
					<div class="banner_bt">
						<button class="read_bt">Read More</button>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>

export default {
    name:'Banner'
}
</script>




