<template>
	<div class=" layout_padding promoted_sectipon">
		<div class="container">
			<h1 class="promoted_text">PROMOTED <span style="border-bottom: 5px solid #4bc714;">ADS</span></h1>
			<div class="images_main">
				<div class="row">
					<div class="col-sm-6 col-md-6 col-lg-3">
						<div class="images"><img src="images/img-1.png" style="width: 100%;"></div>
						<button class="promoted_bt">PROMOTED</button>
						<div class="eye-icon"><img src="images/eye-icon.png"><span class="like-icon"><img src="images/like-icon.png"></span></div>
						<div class="numbar_text">30<span class="like-icon">01</span></div>
						<button class="mobile_bt"><a href="#">Mobiles</a></button>
					</div>
					<div class="col-sm-6 col-md-6 col-lg-3">
						<div class="images"><img src="images/img-2.png" style="width: 100%;"></div>
						<button class="promoted_bt">PROMOTED</button>
						<div class="eye-icon"><img src="images/eye-icon.png"><span class="like-icon"><img src="images/like-icon.png"></span></div>
						<div class="numbar_text">30<span class="like-icon">01</span></div>
						<button class="mobile_bt"><a href="#">Cyicals</a></button>
					</div>
					<div class="col-sm-6 col-md-6 col-lg-3">
						<div class="images"><img src="images/img-3.png" style="width: 100%;"></div>
						<button class="promoted_bt">PROMOTED</button>
						<div class="eye-icon"><img src="images/eye-icon.png"><span class="like-icon"><img src="images/like-icon.png"></span></div>
						<div class="numbar_text">30<span class="like-icon">01</span></div>
						<button class="mobile_bt"><a href="#">Cars</a></button>
					</div>
					<div class="col-sm-6 col-md-6 col-lg-3">
						<div class="images"><img src="images/img-4.png" style="width: 100%;"></div>
						<button class="promoted_bt">PROMOTED</button>
						<div class="eye-icon"><img src="images/eye-icon.png"><span class="like-icon"><img src="images/like-icon.png"></span></div>
						<div class="numbar_text">30<span class="like-icon">01</span></div>
						<button class="mobile_bt"><a href="#">Laptops</a></button>
					</div>
				</div>
			</div>
			<div class="images_main">
				<div class="row">
					<div class="col-sm-6 col-md-6 col-lg-3">
						<div><img src="images/img-1.png" style="width: 100%;"></div>
						<button class="promoted_bt">PROMOTED</button>
						<div class="eye-icon"><img src="images/eye-icon.png"><span class="like-icon"><img src="images/like-icon.png"></span></div>
						<div class="numbar_text">30<span class="like-icon">01</span></div>
						<button class="mobile_bt"><a href="#">Mobiles</a></button>
					</div>
					<div class="col-sm-6 col-md-6 col-lg-3">
						<div><img src="images/img-2.png" style="width: 100%;"></div>
						<button class="promoted_bt">PROMOTED</button>
						<div class="eye-icon"><img src="images/eye-icon.png"><span class="like-icon"><img src="images/like-icon.png"></span></div>
						<div class="numbar_text">30<span class="like-icon">01</span></div>
						<button class="mobile_bt"><a href="#">Cyicals</a></button>
					</div>
					<div class="col-sm-6 col-md-6 col-lg-3">
						<div><img src="images/img-3.png" style="width: 100%;"></div>
						<button class="promoted_bt">PROMOTED</button>
						<div class="eye-icon"><img src="images/eye-icon.png"><span class="like-icon"><img src="images/like-icon.png"></span></div>
						<div class="numbar_text">30<span class="like-icon">01</span></div>
						<button class="mobile_bt"><a href="#">Cars</a></button>
					</div>
					<div class="col-sm-6 col-md-6 col-lg-3">
						<div><img src="images/img-4.png" style="width: 100%;"></div>
						<button class="promoted_bt">PROMOTED</button>
						<div class="eye-icon"><img src="images/eye-icon.png"><span class="like-icon"><img src="images/like-icon.png"></span></div>
						<div class="numbar_text">30<span class="like-icon">01</span></div>
						<button class="mobile_bt"><a href="#">Laptops</a></button>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script>

export default {
    name:'Promot'
}
</script>




