<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>
 
<body>
	Hello <?php echo e($user['firstname']); ?><br/>
	Welcome to the Pet App<br/>
	Your registered email-id is <?php echo e($user['email']); ?><br/>
	Thank's<br/>
	Pet
</body>
 
</html><?php /**PATH /home/rajinder/pet/resources/views/emails/welcome.blade.php ENDPATH**/ ?>